from django.shortcuts import render,redirect
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Room,Guest,Booking
from datetime import datetime, timedelta

from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from django.http import HttpResponse


from datetime import datetime

from datetime import date



from django.db.models.functions import TruncDate
from django.utils.timezone import now













def hello_world(request):
    return HttpResponse("Hello, World!")


def Home(request):
    return render(request,'index.html')





# View to list all rooms



# View to add a new room
def add_room(request):
    if request.method == "POST":
        room_no = request.POST.get('room_no')
        room_type = request.POST.get('room_type')
        status = request.POST.get('status')
        price=request.POST.get('price')
        image = request.FILES.get('image')
        Room.objects.create(
            room_no=room_no,
            room_type=room_type,
            status=status,
            price=price,
            image=image
        )
        return redirect('admin_dashboard')  # Redirect to the room list page
    return render(request, 'add_room.html')

# View to update an existing room

def update_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    if request.method == "POST":
        room.room_no = request.POST.get('room_no')
        room.room_type = request.POST.get('room_type')
        room.status = request.POST.get('status')
        room.price=request.POST.get('price')
        if 'image' in request.FILES:  # Check if a new image is uploaded
            room.image = request.FILES['image']
        room.save()
        return redirect('admin_dashboard')

    return render(request, 'update_room.html', {'room': room})

# View to delete a room
def delete_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    if request.method == "POST":
        room.delete()
        return redirect('admin_dashboard')

    return render(request, 'delete_room.html', {'room': room})


def admin_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None and user.is_staff:
            login(request, user)
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Invalid credentials or you are not an admin!")
            return redirect('admin_login')

    return render(request, 'admin_login.html')





# Admin Dashboard View
@login_required
def admin_dashboard(request):
    rooms = Room.objects.all()  # Get all rooms from the database
    guests = Guest.objects.all()
    bookings = Booking.objects.all()
    
    
    today = now().date()  # Get all bookings
    todays_bookings = Booking.objects.annotate(
        date_only=TruncDate('booking_date')
    ).filter(date_only=today).select_related('guest', 'room')

    return render(request, 'admin_dashboard.html', {
        'rooms': rooms,
        'bookings': bookings,
        'guests':guests,
        'todays_bookings': todays_bookings
    })



    return redirect('add_room')









def room_list(request):
    rooms = Room.objects.all()  # Get all rooms from the database
    #return redirect('admin_dashboard')

    return render(request, 'room_list.html', {'rooms': rooms})





# Admin Logout View
@login_required
def admin_logout(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('admin_login')



# Guest Registration View
def guest_register(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        phone_no=request.POST.get('phone_no')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if password != confirm_password:
            return render(request, 'register.html', {'error': 'Passwords do not match'})

        if Guest.objects.filter(username=username).exists():
            return render(request, 'register.html', {'error': 'Username already exists'})

        if Guest.objects.filter(email=email).exists():
            return render(request, 'register.html', {'error': 'Email already exists'})

        guest = Guest.objects.create_user(
            username=username,
            email=email,
            first_name=first_name,
            last_name=last_name,
            phone_no=phone_no,
            password=password
        )
        return redirect('guest_login')
    return render(request, 'register.html')

'''
# Guest Login View 1 st one
def guest_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        guest = authenticate(request, username=username, password=password)

        if guest is not None:
            login(request, guest)
            return redirect('guest_room_list')
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password'})
    return render(request, 'login.html')'''


# 2nd one



def guest_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        guest = authenticate(request, username=username, password=password)

        if guest is not None:
            if guest.is_active:
                login(request, guest)
                return redirect('guest_dashboard')
            else:
                return render(request, 'login.html', {'error': 'Your account is blocked. Please contact admin.'})
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password.'})

    return render(request, 'login.html')


@login_required
def toggle_guest_status(request, guest_id):
    guest = get_object_or_404(Guest, id=guest_id)

    if request.method == 'POST':
        if guest.is_active:
            guest.is_active = False
            messages.success(request, f"{guest.username} has been blocked.")
        else:
            guest.is_active = True
            messages.success(request, f"{guest.username} has been activated.")

        guest.save()
        return redirect('admin_dashboard')

    return render(request, 'toggle_guest_status.html', {'guest': guest})



























# Guest List View
def guest_list(request):
    #if not request.user.is_authenticated:
        #return redirect('guest_login')

    guests = Guest.objects.all()
    return render(request, 'list.html', {'guests': guests})







# Guest Logout View
def guest_logout(request):
    logout(request)
    return redirect('guest_login')

def guest_room_list(request):
    rooms = Room.objects.all()  # Get all rooms from the database
    rooms = Room.objects.filter(status='Available')  # Show only available rooms
    return render(request, 'guest_room_list.html', {'rooms': rooms})



    return render(request, 'guest_room_list.html', {'rooms': rooms})






def book_now(request):

    return HttpResponse("Your Room booked Successfully")




@login_required
def book_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)

    if room.status != 'Available':
        messages.error(request, "This room is already booked.")
        return redirect('guest_room_list')

    if request.method == 'POST':
        # Create the booking
        booking = Booking.objects.create(
            guest=request.user,
            room=room,
            check_in=datetime(2024, 12, 20, 14, 0),  # Dec 20, 2024, 2:00 PM
            check_out=datetime(2024, 12, 25, 11, 0),
            payment_status='Completed'  # You can handle payment integration here
        )
        # Update the room status
        room.status = 'Booked'
        room.save()
        #return HttpResponse("Room booked successfully!")

        messages.success(request, "Room booked successfully!")
        return redirect('guest_dashboard')  # Redirect to a dashboard or confirmation page

    return render(request, 'book_room.html', {'room': room})


''' # 1st one
def guest_dashboard(request):
    # Get bookings made by the logged-in guest
    bookings = Booking.objects.filter(guest=request.user)
    available_rooms = Room.objects.filter(status='Available')  # Rooms available for booking

    return render(request, 'guest_dashboard.html', {
        'bookings': bookings,
        'available_rooms': available_rooms
    })
'''


#2nd one

@login_required
def guest_dashboard(request):
    if not request.user.is_active:
        messages.error(request, "Your account is blocked. Please contact admin.")
        return redirect('guest_login')

    bookings = Booking.objects.filter(guest=request.user)
    available_rooms = Room.objects.filter(status='Available')
    return render(request, 'guest_dashboard.html', {
        'bookings': bookings,
        'available_rooms': available_rooms
    })





#@login_required
def change_room_status(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    if request.method == 'POST':
        new_status = request.POST.get('status')
        room.status = new_status
        room.save()
        messages.success(request, f"Room status updated to {new_status}!")
        return redirect('admin_dashboard')
    return render(request, 'change_room_status.html', {'room': room})





def guest_room_list1(request):
    rooms = Room.objects.filter(status='Available')  # Show only available rooms
    return render(request, 'guest_room_list.html', {'rooms': rooms})


'''
def bookings_view(request):
    if request.method=="POST":
        fromdate=request.POST.get('fromdate')
        todate=request.POST.get('todate')
        searchdata= Booking.objects.raw('select * from Booking where booking_date  between " '+fromdate+'" and "'+todate+'" ')
        return render(request, 'bookings.html', {'searchdata': searchdata})
    else:
        bookings = Booking.objects.select_related('guest', 'room').all()
        return render(request, 'bookings.html', {'bookings': bookings})


'''

'''
# Fetch all bookings from the database
    bookings = Booking.objects.select_related('guest', 'room').all()

    # Pass the bookings data to the template
    return render(request, 'bookings.html', {'bookings': bookings})





'''





'''

def todays_bookings_view(request):
    """Renders a page showing today's bookings."""
    today = date.today()
    todays_bookings = Booking.objects.filter(booking_date=today).select_related('guest', 'room')

    if not todays_bookings.exists():
        message = "No bookings found for today."
        return render(request, 'todays_bookings.html', {'message': message})

    return render(request, 'todays_bookings.html', {'bookings': todays_bookings})



'''







def todays_bookings_view(request):
    today = now().date()  # Get today's date

    # Use TruncDate to compare only the date part
    todays_bookings = Booking.objects.annotate(
        date_only=TruncDate('booking_date')
    ).filter(date_only=today).select_related('guest', 'room')
    return render(request, 'todays_bookings.html', {
                'todays_bookings': todays_bookings
    })




    #return render(request, 'todays_bookings.html', {
























def front_page(request):
    return render(request,'index.html')


def features(request):
    return render(request, 'features.html')


def guest_dashboard_front(request):
    bookings = Booking.objects.filter(guest=request.user)

    return render(request, 'guest_dashboard_booking.html', {
        'bookings': bookings})



def guest_dashboard_back(request):
    available_rooms = Room.objects.filter(status='Available')
    return render(request, 'guest_dashboard_room_list.html', {

        'available_rooms': available_rooms
    })


def contact(request):
    return render(request, 'contact.html')


'''

def search(request):
    if request.method=="POST":
        fromdate=request.POST.get('fromdate')
        todate=request.POST.get('todate')
        searchdata= Booking.objects.raw('select * from Booking where booking_date  between " '+fromdate+'" and "'+todate+'" ')
        return render(request,'bookings.html','data':searchdata)
    bookings = Booking.objects.select_related('guest', 'room').all()

    # Pass the bookings data to the template
    return render(request, 'bookings.html', {'bookings': bookings})
'''





def bookings_view(request):
    if request.method == "POST":
        fromdate = request.POST.get('fromdate')
        todate = request.POST.get('todate')

        if fromdate and todate:
            try:
                # Convert input dates to the proper format
                from_date = datetime.strptime(fromdate, '%Y-%m-%d').date()
                to_date = datetime.strptime(todate, '%Y-%m-%d').date()

                # Filter using Django ORM
                searchdata = Booking.objects.filter(
                    booking_date__range=(from_date, to_date)
                ).select_related('guest', 'room')

                return render(request, 'bookings.html', {'searchdata': searchdata})
            except ValueError:
                # Handle invalid date formats
                error_message = "Invalid date format. Please use the date picker."
                return render(request, 'bookings.html', {'error': error_message})
        else:
            error_message = "Both 'From' and 'To' dates are required."
            return render(request, 'bookings.html', {'error': error_message})
    else:
        bookings = Booking.objects.select_related('guest', 'room').all()
        return render(request, 'bookings.html', {'bookings': bookings})
