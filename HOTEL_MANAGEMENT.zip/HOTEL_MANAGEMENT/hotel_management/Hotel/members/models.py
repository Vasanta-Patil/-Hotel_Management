from django.db import models
from django.contrib.auth.models import User

from django.contrib.auth.models import AbstractUser, Group, Permission
from django.utils.timezone import now



# Create your models here.

class Room(models.Model):
    ROOM_TYPE_CHOICES = [
        ('AC', 'AC'),
        ('NON_AC', 'Non-AC'),
    ]
    STATUS_CHOICES = [
        ('Available', 'Available'),
        ('Booked', 'Booked'),
        
        
    ]
    
    room_no = models.CharField(max_length=10, unique=True)  # Room number (e.g., '101', 'A1')
    room_type = models.CharField(max_length=7, choices=ROOM_TYPE_CHOICES)  # AC or Non-AC
    status = models.CharField(max_length=12, choices=STATUS_CHOICES, default='AVAILABLE')  # Room status
    price=models.IntegerField()
    image = models.ImageField(upload_to='room_images/', blank=True, null=True)  # Room image

    def __str__(self):
        return f"Room {self.room_no} ({self.room_type})"
    





class Guest(AbstractUser):
    """
    Custom Guest model inheriting from AbstractUser.
    """
    email = models.EmailField(unique=True)
    phone_no = models.CharField(max_length=15)
    is_active = models.BooleanField(default=True)  # Indicates if the guest is active



    

    

    # Override groups and user_permissions to avoid clashes
    groups = models.ManyToManyField(
        Group,
        related_name="guest_users",  # Custom related name
        blank=True,
        help_text="The groups this user belongs to.",
        verbose_name="groups",
    )
    user_permissions = models.ManyToManyField(
        Permission,
        related_name="guest_users",  # Custom related name
        blank=True,
        help_text="Specific permissions for this user.",
        verbose_name="user permissions",
    )

    def __str__(self):
        return f"{self.username} ({self.email})"

    


class Booking(models.Model):
    PAYMENT_STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Completed', 'Completed'),
    ]
    
    guest = models.ForeignKey(Guest, on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    booking_date = models.DateTimeField(auto_now_add=True)
    check_in = models.DateTimeField(default=now)  # Default to current time
    check_out = models.DateTimeField(default=now)
    
    payment_status = models.CharField(
        max_length=10, 
        choices=PAYMENT_STATUS_CHOICES, 
        default='Pending'
    )

    
    def __str__(self):
        return f"Booking by {self.guest.username} for Room {self.room.room_no}"
