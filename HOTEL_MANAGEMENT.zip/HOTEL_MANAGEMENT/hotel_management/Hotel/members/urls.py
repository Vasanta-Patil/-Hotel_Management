from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [

     path('', views.Home, name='Home'),
    path('hello_world',views.hello_world,name="hello_world"),
    path('rooms/', views.room_list, name='room_list'),  # List all rooms
    path('add_room/', views.add_room, name='add_room'),  # Add a new room
    path('update_room/<int:room_id>/', views.update_room, name='update_room'),  # Update a room
    path('delete_room/<int:room_id>/', views.delete_room, name='delete_room'),  # Delete a room

    path('admin_login/', views.admin_login, name='admin_login'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin_logout/', views.admin_logout, name='admin_logout'),
    path('register/', views.guest_register, name='guest_register'),
    path('login/', views.guest_login, name='guest_login'),
    path('list/', views.guest_list, name='guest_list'),
    path('logout/', views.guest_logout, name='guest_logout'),
    path('1/', views.guest_room_list, name='guest_room_list'),
    path('book_now/', views.book_now, name='book_now'),
    path('book-room/<int:room_id>/', views.book_room, name='book_room'),
    path('guest-dashboard/', views.guest_dashboard, name='guest_dashboard'),
    path('change_room_status/', views.change_room_status, name='change_room_status'),
    path('bookings_view/',views. bookings_view, name='bookings_view'),

    path('guest_list/', views.guest_list, name='guest_list'),
    path('toggle-guest-status/<int:guest_id>/', views.toggle_guest_status, name='toggle_guest_status'),
    path('front_page/', views.front_page, name='front_page'),
    path('features/', views.features, name='features'),
    path('guest_dashboard_front/', views.guest_dashboard_front, name='guest_dashboard_front'),
    path('guest_dashboard_back1/', views.guest_dashboard_back, name='guest_dashboard_back'),
    path('contact/', views.contact, name='contact'),
    path('todays_bookings_view/', views.todays_bookings_view, name='todays_bookings_view'),




    #path('search/', views.search, name='search'),
















]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
